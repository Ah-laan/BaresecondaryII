const KEY="bareHighSchoolStudents";
let students=JSON.parse(localStorage.getItem(KEY)||"[]");
const $=id=>document.getElementById(id);
$("regDate").value=new Date().toISOString().slice(0,10);
$("year").textContent=new Date().getFullYear();

$("registrationForm").addEventListener("submit",e=>{
 e.preventDefault();
 const id=$("studentId").value.trim();
 if(students.some(s=>s.studentId.toLowerCase()===id.toLowerCase())) return toast("Student ID already exists.");
 const s={studentId:id,regDate:$("regDate").value,firstName:$("firstName").value.trim(),middleName:$("middleName").value.trim(),lastName:$("lastName").value.trim(),sex:$("sex").value,dob:$("dob").value,grade:$("grade").value,section:$("section").value.trim(),previousSchool:$("previousSchool").value.trim(),phone:$("phone").value.trim(),guardian:$("guardian").value.trim(),guardianPhone:$("guardianPhone").value.trim(),address:$("address").value.trim(),emergency:$("emergency").value.trim(),notes:$("notes").value.trim()};
 students.push(s); save(); e.target.reset(); $("regDate").value=new Date().toISOString().slice(0,10); render(); toast("Student registered successfully.");
});
function save(){localStorage.setItem(KEY,JSON.stringify(students))}
function render(){
 const q=$("search").value.toLowerCase(), gf=$("gradeFilter").value, sf=$("sexFilter").value;
 const data=students.filter(s=>!q||Object.values(s).join(" ").toLowerCase().includes(q)).filter(s=>!gf||s.grade===gf).filter(s=>!sf||s.sex===sf);
 $("studentTable").innerHTML=data.map(s=>`<tr><td>${esc(s.studentId)}</td><td><b>${esc([s.firstName,s.middleName,s.lastName].filter(Boolean).join(" "))}</b><br><small>${esc(s.dob)}</small></td><td>${esc(s.sex)}</td><td>${esc(s.grade)}${s.section?"-"+esc(s.section):""}</td><td>${esc(s.guardian)}</td><td>${esc(s.guardianPhone)}</td><td>${esc(s.regDate)}</td><td><button class="action print" onclick="printStudent('${encodeURIComponent(s.studentId)}')">Print</button><button class="action delete" onclick="removeStudent('${encodeURIComponent(s.studentId)}')">Delete</button></td></tr>`).join("");
 $("empty").style.display=data.length?"none":"block";
 $("totalStudents").textContent=students.length;
 $("maleStudents").textContent=students.filter(s=>s.sex==="Male").length;
 $("femaleStudents").textContent=students.filter(s=>s.sex==="Female").length;
}
function removeStudent(encoded){const id=decodeURIComponent(encoded);if(confirm("Delete this registration?")){students=students.filter(s=>s.studentId!==id);save();render();toast("Registration deleted.")}}
function printStudent(encoded){
 const s=students.find(x=>x.studentId===decodeURIComponent(encoded)); if(!s)return;
 const name=[s.firstName,s.middleName,s.lastName].filter(Boolean).join(" ");
 const w=window.open("","_blank"); w.document.write(`<html><head><title>Student Registration - ${esc(s.studentId)}</title><style>body{font-family:Arial;padding:40px}h1{text-align:center;color:#0b3d91}.box{max-width:700px;margin:auto;border:1px solid #ddd;padding:25px}p{padding:8px;border-bottom:1px solid #eee}</style></head><body><div class="box"><h1>Bare High School</h1><h2>Student Registration Record</h2><p><b>Student ID:</b> ${esc(s.studentId)}</p><p><b>Name:</b> ${esc(name)}</p><p><b>Sex:</b> ${esc(s.sex)}</p><p><b>Date of Birth:</b> ${esc(s.dob)}</p><p><b>Grade/Section:</b> ${esc(s.grade)} / ${esc(s.section)}</p><p><b>Guardian:</b> ${esc(s.guardian)}</p><p><b>Guardian Phone:</b> ${esc(s.guardianPhone)}</p><p><b>Address:</b> ${esc(s.address)}</p><p><b>Registration Date:</b> ${esc(s.regDate)}</p></div><script>window.print()<\/script></body></html>`);w.document.close()
}
function exportCSV(){
 if(!students.length)return toast("No records to export.");
 const headers=Object.keys(students[0]); const rows=[headers,...students.map(s=>headers.map(h=>s[h]??""))];
 const csv=rows.map(r=>r.map(v=>`"${String(v).replaceAll('"','""')}"`).join(",")).join("\n");
 const blob=new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="bare_high_school_student_registrations.csv";a.click();URL.revokeObjectURL(a.href);toast("CSV downloaded.");
}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function toast(msg){$("toast").textContent=msg;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2500)}
render();