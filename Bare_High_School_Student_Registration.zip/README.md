# Bare High School Student Registration System

## Deploy
This is a static website and can be deployed on GitHub Pages, Netlify, Vercel, cPanel/static hosting, or any web server.

1. Upload `index.html`, `style.css`, and `app.js` to your hosting folder.
2. Open `index.html` in the browser.
3. Student records are stored in the browser's `localStorage`.

## Features
- Responsive student registration form
- Student ID duplicate checking
- Grade 9–12 and section
- Male/Female statistics
- Search and filters
- Print individual registration records
- CSV export compatible with Excel
- Delete records
- No database/server required

## Important production note
This version is ideal for a simple deployable prototype or single-device office use. Because records are stored in the browser, data is not automatically shared between different computers/phones. For a multi-user school system with secure login, a central database, backups, and simultaneous access, connect the frontend to a backend such as PHP/MySQL, Node.js/PostgreSQL, or Supabase/Firebase.
